// isr of the toggle button
extern bool menu_toggle;
extern bool antenne;
extern int batterij_inlezen;

#define lba_switch PB_1
// control of FM switch

#define batterij_inlezen PB_0

void main_display();
void second_display();
void aanpassen(int level);

void toggle_menu()
{
    menu_toggle = !menu_toggle;
}
bool get_menu()
{
    return menu_toggle;
}
float batterij_niveau()
{

    float reading, voltage;

    reading = analogRead(PB0);
    voltage = (reading * 3.3) / 4096;
    return voltage;
}
void strepen(float voltage)
{

    String str;
    /* aangezien een switchas geen float of double types support, ook niet met een range van getallen, is er gekozen om een else if constructie toe te passen
     */
    if (voltage >= 1.15 and voltage < 2.00)
    {
        // 7.5 volt
        // 4 streepjes
        aanpassen(0);
        str = "4 strepen";
    }
    else if (voltage >= 1.07 and voltage < 1.15)
    {
        // 7 volt
        // 3 streepjes
        aanpassen(1);
        str = "3 strepen";
    }
    else if (voltage >= 1.01 and voltage < 1.07)
    {
        // 6.5 volt
        // 2 streepjes
        aanpassen(2);
        str = "2 strepen";
    }
    else if (voltage >= 0.94 and voltage < 1.01)
    {
        // 6 volt
        // 1 streepjes
        aanpassen(3);
        str = "1 streep";
    }
    else if (voltage >= 0.19 and voltage < 0.94)
    {
        // 5.5 volt
        // 0 streepjes
        aanpassen(4);
        str = "0 strepen";
    }
  //  return str;
}
bool get_antenne()
{
    return antenne;
}
void toggle_antenne()
{
    antenne = !antenne;
}
void LBA_uitzetten()
{
    digitalWrite(lba_switch, LOW);
}
void LBA_aanzetten()
{
    digitalWrite(lba_switch, HIGH);
}
void passive_antennne()
{

    // LBA_uitzetten();
    //  de rf switch omzetten naar headphones
    digitalWrite(PA15, LOW);
    digitalWrite(PA14, HIGH);
}
void actieve_antenne()
{
    // LBA_aanzetten();
    digitalWrite(PA15, HIGH);
    digitalWrite(PA14, LOW);
}